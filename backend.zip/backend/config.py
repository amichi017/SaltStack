DEBUG = False
TESTING = False
CSRF_ENABLED = True
SECRET_KEY = "this-is-secret-key"
# JWT_ACCESS_TOKEN_EXPIRES = False

MAIL_SERVER = 'smtp.gmail.com'
MAIL_PORT = 465
MAIL_USERNAME = 'notifsalt@gmail.com'
MAIL_PASSWORD = 'Salt5t@ck'
MAIL_USE_SSL = True
MONGO_URI = 'mongodb://localhost:27017/salt'
MONGO_USERNAME = 'saltstack'
MONGO_PASSWORD = 'Salt5t@ck'